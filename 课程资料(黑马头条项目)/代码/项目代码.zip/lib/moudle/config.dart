class Config {
  static String baseUrl = 'http://39.105.192.164:9090/api';
  
}